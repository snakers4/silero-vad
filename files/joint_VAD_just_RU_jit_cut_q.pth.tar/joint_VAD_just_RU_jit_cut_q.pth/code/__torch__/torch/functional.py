def stft(input: Tensor,
    n_fft: int,
    hop_length: Optional[int]=None,
    win_length: Optional[int]=None,
    window: Optional[Tensor]=None,
    center: bool=True,
    pad_mode: str="reflect",
    normalized: bool=False,
    onesided: Optional[bool]=None,
    return_complex: Optional[bool]=None) -> Tensor:
  if center:
    signal_dim = torch.dim(input)
    _0 = torch.mul([1], torch.sub(3, signal_dim))
    extended_shape = torch.add(_0, torch.list(torch.size(input)))
    pad = torch.floordiv(n_fft, 2)
    input1 = __torch__.torch.nn.functional._pad(torch.view(input, extended_shape), [pad, pad], pad_mode, 0., )
    _1 = torch.slice(torch.size(input1), torch.neg(signal_dim), 9223372036854775807, 1)
    input0 = torch.view(input1, _1)
  else:
    input0 = input
  _2 = torch.stft(input0, n_fft, hop_length, win_length, window, normalized, onesided, return_complex)
  return _2

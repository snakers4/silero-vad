class ReflectionPad1d(Module):
  __parameters__ = []
  __buffers__ = []
  training : bool
  padding : Final[Tuple[int, int]] = (20, 20)
  def forward(self: __torch__.torch.nn.modules.padding.ReflectionPad1d,
    input: Tensor) -> Tensor:
    _0 = __torch__.torch.nn.functional._pad(input, [20, 20], "reflect", 0., )
    return _0

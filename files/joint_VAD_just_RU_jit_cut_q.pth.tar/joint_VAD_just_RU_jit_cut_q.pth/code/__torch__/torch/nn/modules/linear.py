class Identity(Module):
  __parameters__ = []
  __buffers__ = []
  training : bool
  def forward(self: __torch__.torch.nn.modules.linear.Identity,
    input: Tensor) -> Tensor:
    return input

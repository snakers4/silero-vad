class AdaptiveAudioNormalization(Module):
  __parameters__ = []
  __buffers__ = ["filter_", ]
  filter_ : Tensor
  training : bool
  reflect : __torch__.torch.nn.modules.padding.ReflectionPad1d
  def forward(self: __torch__.models.stt_model_blocks.AdaptiveAudioNormalization,
    spect: Tensor) -> Tensor:
    spect0 = torch.log1p(torch.mul(spect, 1048576))
    _0 = torch.eq(torch.len(torch.size(spect0)), 2)
    if _0:
      _1 = torch.slice(torch.unsqueeze(spect0, 0), 1, 0, 9223372036854775807, 1)
      spect2 = torch.slice(_1, 2, 0, 9223372036854775807, 1)
      spect1 = spect2
    else:
      spect1 = spect0
    mean = torch.mean(spect1, [1], True, dtype=None)
    mean0 = (self.reflect).forward(mean, )
    mean1 = torch.conv1d(mean0, self.filter_, None, [1], [0], [1], 1)
    mean_mean = torch.mean(mean1, [-1], True, dtype=None)
    spect3 = torch.add(spect1, torch.neg(mean_mean), alpha=1)
    return spect3

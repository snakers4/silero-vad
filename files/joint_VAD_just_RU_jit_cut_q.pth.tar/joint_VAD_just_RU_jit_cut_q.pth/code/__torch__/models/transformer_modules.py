class SelfAttention(Module):
  __parameters__ = ["attention_weights", ]
  __buffers__ = []
  attention_weights : Tensor
  training : bool
  batch_first : bool
  softmax : __torch__.torch.nn.modules.activation.Softmax
  non_linearity : __torch__.torch.nn.modules.activation.Tanh
  def forward(self: __torch__.models.transformer_modules.SelfAttention,
    inputs: Tensor) -> Tensor:
    _0 = self.non_linearity
    _1 = torch.matmul(inputs, self.attention_weights)
    scores = (_0).forward(_1, )
    scores0 = (self.softmax).forward(scores, )
    _2 = torch.expand_as(torch.unsqueeze(scores0, -1), inputs)
    weighted = torch.mul(inputs, _2)
    representations = torch.sum(weighted, [1], False, dtype=None)
    return representations

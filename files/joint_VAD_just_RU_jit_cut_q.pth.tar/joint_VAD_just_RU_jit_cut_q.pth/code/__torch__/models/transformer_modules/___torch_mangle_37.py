class MultiHeadAttention(Module):
  __parameters__ = []
  __buffers__ = []
  training : bool
  scale : float
  n_heads : int
  has_out_proj : bool
  QKV : __torch__.torch.nn.quantized.dynamic.modules.linear.Linear
  out_proj : __torch__.torch.nn.quantized.dynamic.modules.linear.Linear
  def forward(self: __torch__.models.transformer_modules.___torch_mangle_37.MultiHeadAttention,
    x: Tensor) -> Tensor:
    _0 = __torch__.torch.nn.functional.softmax
    bsz, seq, dim, = torch.size(x)
    head_dim = torch.floordiv(dim, self.n_heads)
    _1 = torch.chunk((self.QKV).forward(x, ), 3, -1)
    q, k, v, = _1
    _2 = torch.contiguous(torch.transpose(k, 0, 1), memory_format=0)
    _3 = [seq, torch.mul(bsz, self.n_heads), head_dim]
    k0 = torch.transpose(torch.view(_2, _3), 0, 1)
    _4 = torch.contiguous(torch.transpose(q, 0, 1), memory_format=0)
    _5 = [seq, torch.mul(bsz, self.n_heads), head_dim]
    q0 = torch.transpose(torch.view(_4, _5), 0, 1)
    _6 = torch.contiguous(torch.transpose(v, 0, 1), memory_format=0)
    _7 = [seq, torch.mul(bsz, self.n_heads), head_dim]
    v0 = torch.transpose(torch.view(_6, _7), 0, 1)
    _8 = torch.matmul(k0, torch.transpose(q0, 1, 2))
    alpha = _0(torch.div(_8, self.scale), -1, 3, None, )
    attn = torch.matmul(alpha, v0)
    _9 = torch.contiguous(torch.transpose(attn, 0, 1), memory_format=0)
    attn0 = torch.transpose(torch.view(_9, [seq, bsz, dim]), 0, 1)
    if self.has_out_proj:
      attn1 = (self.out_proj).forward(attn0, )
    else:
      attn1 = attn0
    return attn1

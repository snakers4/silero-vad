class TransformerLayer(Module):
  __parameters__ = []
  __buffers__ = []
  training : bool
  reshape_inputs : bool
  attention : __torch__.models.transformer_modules.___torch_mangle_37.MultiHeadAttention
  activation : __torch__.torch.nn.modules.activation.ReLU
  linear1 : __torch__.torch.nn.quantized.dynamic.modules.linear.Linear
  linear2 : __torch__.torch.nn.quantized.dynamic.modules.linear.Linear
  norm1 : __torch__.torch.nn.modules.normalization.___torch_mangle_21.LayerNorm
  norm2 : __torch__.torch.nn.modules.normalization.___torch_mangle_21.LayerNorm
  dropout : __torch__.torch.nn.modules.dropout.Dropout
  dropout1 : __torch__.torch.nn.modules.dropout.Dropout
  dropout2 : __torch__.torch.nn.modules.dropout.Dropout
  def forward(self: __torch__.models.transformer_modules.___torch_mangle_39.TransformerLayer,
    x: Tensor) -> Tensor:
    if self.reshape_inputs:
      x1 = torch.contiguous(torch.permute(x, [0, 2, 1]), memory_format=0)
      x0 = x1
    else:
      x0 = x
    attn = (self.attention).forward(x0, )
    x2 = torch.add(x0, (self.dropout1).forward(attn, ), alpha=1)
    x3 = (self.norm1).forward(x2, )
    _0 = self.linear2
    _1 = self.dropout
    _2 = (self.activation).forward((self.linear1).forward(x3, ), )
    x20 = (_0).forward((_1).forward(_2, ), )
    x4 = torch.add(x3, (self.dropout2).forward(x20, ), alpha=1)
    x5 = (self.norm2).forward(x4, )
    if self.reshape_inputs:
      x7 = torch.contiguous(torch.permute(x5, [0, 2, 1]), memory_format=0)
      x6 = x7
    else:
      x6 = x5
    return x6

class FeatureExtractor(Module):
  __parameters__ = []
  __buffers__ = []
  training : bool
  extractor : __torch__.models.number_vad_model.STFTExtractor
  def forward(self: __torch__.models.number_vad_model.FeatureExtractor,
    wav: Tensor) -> Tensor:
    return (self.extractor).forward(wav, )
class STFTExtractor(Module):
  __parameters__ = []
  __buffers__ = []
  training : bool
  sr : int
  n_fft : int
  win_length : int
  hop_length : int
  mode : str
  def forward(self: __torch__.models.number_vad_model.STFTExtractor,
    wav: Tensor) -> Tensor:
    _0 = __torch__.torchaudio.functional.magphase
    _1 = uninitialized(Tensor)
    _2 = self.n_fft
    _3 = self.win_length
    stft_sample = __torch__.torch.functional.stft(wav, _2, self.hop_length, _3, None, True, "reflect", False, None, None, )
    mag, phase, = _0(stft_sample, 1., )
    if torch.eq(self.mode, "mag"):
      _4 = mag
    else:
      if torch.eq(self.mode, "phase"):
        _5 = phase
      else:
        if torch.eq(self.mode, "magphase"):
          _7 = torch.mul(mag, torch.cos(phase))
          _8 = torch.mul(mag, torch.sin(phase))
          _6 = torch.cat([_7, _8], 1)
        else:
          ops.prim.RaiseException("")
          _6 = _1
        _5 = _6
      _4 = _5
    return _4
class ConvBlock(Module):
  __parameters__ = []
  __buffers__ = []
  training : bool
  proj : None
  dw_conv : __torch__.torch.nn.modules.container.Sequential
  pw_conv : __torch__.torch.nn.modules.container.___torch_mangle_1.Sequential
  activation : __torch__.torch.nn.modules.activation.ReLU
  def forward(self: __torch__.models.number_vad_model.ConvBlock,
    x: Tensor) -> Tensor:
    x0 = (self.pw_conv).forward((self.dw_conv).forward(x, ), )
    x1 = torch.add_(x0, x, alpha=1)
    return (self.activation).forward(x1, )

class Net_convertable(Module):
  __parameters__ = []
  __buffers__ = []
  training : bool
  feature_extractor : __torch__.models.number_vad_model.FeatureExtractor
  adaptive_normalization : __torch__.models.stt_model_blocks.AdaptiveAudioNormalization
  encoder : __torch__.torch.nn.modules.container.___torch_mangle_40.Sequential
  decoder_number : __torch__.torch.nn.modules.container.___torch_mangle_41.Sequential
  decoder : __torch__.torch.nn.modules.container.___torch_mangle_42.Sequential
  lang_classifier : __torch__.torch.nn.quantized.dynamic.modules.linear.Linear
  attention : __torch__.models.transformer_modules.SelfAttention
  detection_clf : __torch__.torch.nn.quantized.dynamic.modules.linear.Linear
  sigmoid : __torch__.torch.nn.modules.activation.Sigmoid
  def forward(self: __torch__.models.number_vad_model.___torch_mangle_43.Net_convertable,
    x: Tensor,
    vad: bool=True,
    number_vad: bool=True,
    language_classify: bool=True) -> Tuple[Tensor, Tensor, Tensor, Tensor]:
    _0 = "Audio length must be 4000 samples for Vad"
    _1 = uninitialized(Tensor)
    x0 = (self.feature_extractor).forward(x, )
    x1 = (self.adaptive_normalization).forward(x0, )
    x2 = (self.encoder).forward(x1, )
    attention_scores = (self.attention).forward(torch.permute(x2, [0, 2, 1]), )
    vad_logits = torch.empty([0], dtype=None, layout=None, device=None, pin_memory=None, memory_format=None)
    perframe_logits = torch.empty([0], dtype=None, layout=None, device=None, pin_memory=None, memory_format=None)
    detection_logits = torch.empty([0], dtype=None, layout=None, device=None, pin_memory=None, memory_format=None)
    lang_logits = torch.empty([0], dtype=None, layout=None, device=None, pin_memory=None, memory_format=None)
    if vad:
      if torch.ne((torch.size(x2))[2], 4):
        ops.prim.RaiseException(_0)
        vad_logits1 = _1
      else:
        _2 = self.sigmoid
        _3 = torch.squeeze((self.decoder).forward(x2, ))
        vad_logits1 = (_2).forward(_3, )
      vad_logits0 = vad_logits1
    else:
      vad_logits0 = vad_logits
    if number_vad:
      detection_logits1 = (self.detection_clf).forward(attention_scores, )
      _4 = (self.decoder_number).forward(torch.permute(x2, [0, 2, 1]), )
      perframe_logits0, detection_logits0 = torch.permute(_4, [0, 2, 1]), detection_logits1
    else:
      perframe_logits0, detection_logits0 = perframe_logits, detection_logits
    if language_classify:
      lang_logits1 = (self.lang_classifier).forward(attention_scores, )
      lang_logits0 = lang_logits1
    else:
      lang_logits0 = lang_logits
    _5 = (perframe_logits0, detection_logits0, vad_logits0, lang_logits0)
    return _5

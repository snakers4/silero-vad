class ConvBlock(Module):
  __parameters__ = []
  __buffers__ = []
  training : bool
  dw_conv : __torch__.torch.nn.modules.container.___torch_mangle_9.Sequential
  pw_conv : __torch__.torch.nn.modules.container.___torch_mangle_15.Sequential
  proj : __torch__.torch.nn.modules.conv.___torch_mangle_14.Conv1d
  activation : __torch__.torch.nn.modules.activation.ReLU
  def forward(self: __torch__.models.number_vad_model.___torch_mangle_16.ConvBlock,
    x: Tensor) -> Tensor:
    x0 = (self.pw_conv).forward((self.dw_conv).forward(x, ), )
    residual = (self.proj).forward(x, )
    x1 = torch.add_(x0, residual, alpha=1)
    return (self.activation).forward(x1, )

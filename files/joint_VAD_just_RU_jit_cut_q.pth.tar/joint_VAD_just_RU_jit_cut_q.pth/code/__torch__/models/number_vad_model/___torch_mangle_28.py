class ConvBlock(Module):
  __parameters__ = []
  __buffers__ = []
  training : bool
  proj : None
  dw_conv : __torch__.torch.nn.modules.container.___torch_mangle_26.Sequential
  pw_conv : __torch__.torch.nn.modules.container.___torch_mangle_27.Sequential
  activation : __torch__.torch.nn.modules.activation.ReLU
  def forward(self: __torch__.models.number_vad_model.___torch_mangle_28.ConvBlock,
    x: Tensor) -> Tensor:
    x0 = (self.pw_conv).forward((self.dw_conv).forward(x, ), )
    x1 = torch.add_(x0, x, alpha=1)
    return (self.activation).forward(x1, )

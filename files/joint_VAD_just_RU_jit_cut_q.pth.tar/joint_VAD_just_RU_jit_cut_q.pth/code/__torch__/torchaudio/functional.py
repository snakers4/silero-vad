def magphase(complex_tensor: Tensor,
    power: float=1.) -> Tuple[Tensor, Tensor]:
  _0 = __torch__.torchaudio.functional.complex_norm
  mag = _0(complex_tensor, power, )
  phase = __torch__.torchaudio.functional.angle(complex_tensor, )
  return (mag, phase)
def complex_norm(complex_tensor: Tensor,
    power: float=1.) -> Tensor:
  _1 = torch.sum(torch.pow(complex_tensor, 2.), [-1], False, dtype=None)
  return torch.pow(_1, torch.mul(0.5, power))
def angle(complex_tensor: Tensor) -> Tensor:
  _2 = torch.atan2(torch.select(complex_tensor, -1, 1), torch.select(complex_tensor, -1, 0))
  return _2
